# URLSentinel AI

An experimental phishing-URL investigation dashboard combining a URL-only Random Forest classifier, OpenPhish feed context, passive RDAP registration metadata, hostname relationship graphs, and Gemini-generated evidence summaries.

## Features
- **Overview:** current OpenPhish feed statistics (not the training dataset).
- **URL Investigator:** URL-only model inference (12 features), OpenPhish exact URL / hostname matching, on-demand RDAP metadata.
- **Campaign Explorer:** bipartite URL-to-hostname graph. A shared hostname does **not** establish a coordinated campaign.
- **AI Investigation:** Gemini 3.5 Flash Lite generates a report using selected structured features, feed findings and RDAP results.
- **Model Performance:** historical random and hostname-separated split metrics from `evaluation.json`.

## Files

The project requires these existing files from your GitHub repository: `train_model.py`, `predict.py`, `threat_intel.py`, `domain_intel.py`, `ai_investigator.py`, `urlsentinel_model.pkl`, `evaluation.json`. The package provides `app.py`, `requirements.txt`, and tests. Keep the trained model and evaluation JSON in the repository root or update paths accordingly.

## Deployment

1. Review and commit `app.py`, `requirements.txt`, and README to your GitHub repository. Keep existing Python modules and model artifact.
2. Deploy `app.py` with Streamlit Community Cloud.
3. In Streamlit app settings, add secret `GEMINI_API_KEY = "..."`. **Never commit real secrets.**
4. Verify prediction with a known benign example and a synthetic suspicious-looking `.test` URL. A score is not proof of safety or maliciousness.
5. Test OpenPhish feed loading, passive RDAP on `example.com`, Gemini report generation, and graph rendering.

## Security and operational limitations

- **RDAP deployment gate:** The existing `domain_intel.py` prototype uses endpoints from IANA bootstrap but is **not sufficiently hardened for arbitrary public input**. Before public launch, use the replacement `domain_intel.py` included in this package and test it. The hardened module restricts RDAP lookups to an explicit registry host allowlist and disables redirects. Other TLDs will return unavailable until reviewed and allowlisted.
- No submitted website is visited. RDAP requests query registration services, not website content.
- Public OpenPhish feed content changes; 300 feed URLs does not mean 300 training examples.
- Gemini free-tier requests may be used for service improvement; send only selected public/derived features and never private user data.
- The training set contains 235,795 original UCI records (dataset 967); evaluation results from that dataset are **not** independently validated real-world detection accuracy.
- Pickle/joblib artifacts must be loaded only from trusted sources. Retrain with a compatible scikit-learn version if model loading emits a version mismatch warning.
- Domain age, TLS/HTTPS presence, and a public feed miss are not proof of legitimacy.

## Testing

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python -m streamlit run app.py
```

Local unit tests were not executed successfully in the packaging environment because `tldextract` and `ucimlrepo` were unavailable; install dependencies and run them before deployment. Full deployed integration tests require the trained model, external feed availability and a configured Gemini key.
