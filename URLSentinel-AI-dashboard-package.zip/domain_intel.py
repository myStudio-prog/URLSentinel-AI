"""Conservative passive RDAP client. Only fixed reviewed registry endpoints.

Replace existing domain_intel.py with this file before public deployment.
"""
import ipaddress
import re
from urllib.parse import urlsplit, quote
import requests
import tldextract

# Reviewed HTTPS RDAP endpoints; no arbitrary URLs, no redirects.
REGISTRY_ENDPOINTS = {
    'com': 'https://rdap.verisign.com/com/v1/',
    'net': 'https://rdap.verisign.com/net/v1/',
    'org': 'https://rdap.publicinterestregistry.org/rdap/',
    'in': 'https://rdap.nixiregistry.in/rdap/',
    'uk': 'https://rdap.nominet.uk/uk/',
}
# Bundled PSL snapshot; avoid network fetching when extracting registered domain.
EXTRACT = tldextract.TLDExtract(suffix_list_urls=())
LABEL = re.compile(r'^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$')


def registered_domain(hostname):
    if not isinstance(hostname, str):
        return None
    host = hostname.strip().rstrip('.').lower()
    if not host or len(host) > 253 or '/' in host or ':' in host or '@' in host:
        return None
    try:
        ipaddress.ip_address(host)
        return None
    except ValueError:
        pass
    try:
        host = host.encode('idna').decode('ascii')
    except (UnicodeError, ValueError):
        return None
    if any(not LABEL.fullmatch(part) for part in host.split('.')):
        return None
    parsed = EXTRACT(host)
    return parsed.top_domain_under_public_suffix or None


def lookup_domain(hostname):
    domain = registered_domain(hostname)
    if not domain:
        return {'error': 'No valid registered domain found'}
    tld = domain.rsplit('.', 1)[-1]
    endpoint = REGISTRY_ENDPOINTS.get(tld)
    if not endpoint:
        return {'error': 'Registry not in reviewed RDAP endpoint allowlist'}
    # Host is hardcoded in REGISTRY_ENDPOINTS, not influenced by the submitted URL.
    rdap_url = endpoint + 'domain/' + quote(domain, safe='')
    try:
        response = requests.get(rdap_url, timeout=(5, 12), allow_redirects=False,
                                headers={'Accept': 'application/rdap+json'})
        if response.status_code != 200:
            return {'error': f'RDAP unavailable (HTTP {response.status_code})'}
        data = response.json()
        if not isinstance(data, dict):
            return {'error': 'Unexpected RDAP response'}
        events = {e.get('eventAction'): e.get('eventDate')
                  for e in data.get('events', []) if isinstance(e, dict)}
        return {'domain': data.get('ldhName', domain),
                'registration_date': events.get('registration'),
                'expiration_date': events.get('expiration'),
                'last_changed': events.get('last changed'),
                'status': data.get('status', []),
                'source': urlsplit(endpoint).hostname}
    except (requests.RequestException, ValueError, KeyError, TypeError):
        return {'error': 'RDAP lookup failed or returned invalid data'}
