from train_model import clean_url, extract_features

def test_markdown_cleanup():
    assert clean_url('[https://example.com](https://example.com)') == 'https://example.com'

def test_features():
    f=extract_features('https://www.google.com')
    assert len(f)==12
    assert f['uses_https']==1
    assert f['is_ip']==0
