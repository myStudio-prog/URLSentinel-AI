from domain_intel import registered_domain, lookup_domain

def test_registered_domain():
    assert registered_domain('login.security.example.co.uk')=='example.co.uk'
    assert registered_domain('www.example.com')=='example.com'

def test_reject_unsafe():
    for value in ['127.0.0.1','localhost','example.com:8080','evil.com/path','a..com']:
        assert registered_domain(value) is None

def test_unsupported_domain_does_not_network():
    assert 'error' in lookup_domain('example.xyz')
