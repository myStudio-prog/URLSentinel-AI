"""URLSentinel AI | Streamlit investigation dashboard."""
import json
from pathlib import Path
from urllib.parse import urlsplit
import streamlit as st
import pandas as pd
import networkx as nx
from pyvis.network import Network
import streamlit.components.v1 as components
from predict import predict_url
from threat_intel import load_phishing_feed, find_related_hosts
from domain_intel import lookup_domain
from ai_investigator import generate_investigation_report

st.set_page_config(page_title='URLSentinel AI', page_icon='🛡️', layout='wide')
st.markdown('''<style>
.block-container {padding-top:1.5rem;max-width:1380px}
[data-testid="stMetric"] {border:1px solid #33415544;border-radius:14px;padding:16px}
h1,h2,h3 {letter-spacing:-.03em}
</style>''', unsafe_allow_html=True)
st.title('🛡️ URLSentinel AI')
st.caption('Phishing URL detection · Threat intelligence · Evidence-grounded investigation')

@st.cache_data(ttl=3600, show_spinner=False)
def feed_data():
    return load_phishing_feed()

@st.cache_data(show_spinner=False)
def metrics_data():
    for p in (Path('evaluation.json'), Path('artifacts/evaluation.json')):
        if p.exists():
            return json.loads(p.read_text(encoding='utf-8'))
    return {}

def safe_feed():
    try:
        return feed_data(), None
    except Exception:
        return pd.DataFrame(columns=['url','hostname']), 'Feed temporarily unavailable. Predictions remain usable.'

def feed_evidence(url, df):
    hostname = (urlsplit(url).hostname or '').lower()
    return {'exact_url_in_feed': bool((df['url'] == url).any()),
            'same_hostname_url_count': int((df['hostname'].fillna('').str.lower() == hostname).sum()),
            'feed_source': 'OpenPhish public feed (snapshot at application fetch time)'}

pages = st.tabs(['Overview','URL Investigator','Campaign Explorer','AI Investigation','Model Performance'])
with pages[0]:
    st.subheader('Threat intelligence overview')
    feed, error = safe_feed()
    if error: st.warning(error)
    groups = find_related_hosts(feed) if not feed.empty else pd.DataFrame(columns=['hostname','url_count'])
    a,b,c = st.columns(3)
    a.metric('Feed URLs',f'{len(feed):,}')
    b.metric('Unique hostnames',f'{feed.hostname.nunique():,}')
    c.metric('Repeated hostname groups',f'{len(groups):,}')
    st.caption('Feed size is independent of the UCI training dataset. Shared hostnames do not establish coordinated campaigns.')
    st.subheader('Reported URL intelligence')
    st.dataframe(feed[['url','hostname']].head(100), width='stretch', hide_index=True,
                 column_config={'url':st.column_config.TextColumn('Reported URL')})
    st.info('Use URL Investigator to analyze URL text without visiting the submitted website.')

with pages[1]:
    st.subheader('URL Investigator')
    st.caption('Model analysis uses URL text only. No website content is fetched.')
    with st.form('investigate'):
        raw_url=st.text_input('URL to investigate',placeholder='https://example.com/login')
        submitted=st.form_submit_button('Analyze URL',type='primary')
    if submitted:
        try:
            if len(raw_url)>4096 or not raw_url.strip(): raise ValueError('Enter a URL under 4,096 characters.')
            result=predict_url(raw_url.strip())
            result['hostname']=urlsplit(raw_url.strip()).hostname
            st.session_state['urlsentinel_result']=result
            st.session_state.pop('urlsentinel_rdap',None)
            st.session_state.pop('urlsentinel_report',None)
        except Exception as exc:
            st.error(f'URL analysis failed: {type(exc).__name__}. Check URL format and model compatibility.')
    result=st.session_state.get('urlsentinel_result')
    if result:
        a,b,c=st.columns(3)
        a.metric('Model assessment',result['prediction'])
        b.metric('Experimental phishing score',f"{result['phishing_score']:.2f}%")
        c.metric('Hostname',result['hostname'])
        st.caption('Model scores are not calibrated probabilities or proof of malicious activity.')
        with st.expander('12 extracted URL features'):
            st.dataframe(pd.DataFrame([result['features']]),hide_index=True,width='stretch')
        feed,_=safe_feed()
        intel=feed_evidence(result['url'],feed)
        st.session_state['urlsentinel_feed_evidence']=intel
        st.subheader('OpenPhish cross-check')
        x,y=st.columns(2)
        x.metric('Exact feed match','Yes' if intel['exact_url_in_feed'] else 'No')
        y.metric('Same-hostname URLs',intel['same_hostname_url_count'])
        st.caption('No match in a sampled public feed does not establish safety.')
        st.subheader('Domain registration (RDAP)')
        if st.button('Retrieve passive RDAP metadata'):
            try:
                st.session_state['urlsentinel_rdap']=lookup_domain(result['hostname'])
            except Exception as exc:
                st.session_state['urlsentinel_rdap']={'error':f'Lookup unavailable ({type(exc).__name__})'}
        rdap=st.session_state.get('urlsentinel_rdap')
        if rdap:
            if rdap.get('error'):st.warning(rdap['error'])
            else:
                for key in ('domain','registration_date','expiration_date','last_changed','status'):
                    st.write(f'**{key.replace("_"," ").title()}:**',rdap.get(key,'Not available'))
            st.caption('RDAP is public metadata. Registration age and status do not prove legitimacy or fraud.')

with pages[2]:
    st.subheader('Hostname relationship explorer')
    feed,error=safe_feed()
    if error:st.warning(error)
    if feed.empty: st.info('No feed data available.')
    else:
        groups=find_related_hosts(feed)
        st.dataframe(groups.head(40),hide_index=True,width='stretch')
        limit=st.slider('Reported URLs in graph',10,100,40)
        graph=nx.Graph()
        for i,rec in feed.head(limit).reset_index(drop=True).iterrows():
            host=str(rec['hostname'])
            graph.add_node(f'u{i}',label=f'URL {i+1}',kind='url')
            graph.add_node(f'h:{host}',label=host,kind='host')
            graph.add_edge(f'u{i}',f'h:{host}')
        net=Network(height='520px',width='100%',bgcolor='#0b1220',font_color='#f8fafc')
        for node,attr in graph.nodes(data=True):
            net.add_node(node,label=attr['label'],color='#38bdf8' if attr['kind']=='host' else '#f59e0b')
        for u,v in graph.edges():net.add_edge(u,v)
        components.html(net.generate_html(),height=540,scrolling=False)
        st.caption('Edges mean URL-to-hostname association only; not confirmed attacker or campaign links.')

with pages[3]:
    st.subheader('AI Investigation')
    result=st.session_state.get('urlsentinel_result')
    if not result:
        st.info('First analyze a URL in the URL Investigator tab.')
    else:
        st.write('**Assessment:**',result['prediction'])
        st.write('**Experimental score:**',f"{result['phishing_score']:.2f}%")
        st.caption('Gemini receives selected structured evidence only, not the submitted URL or private records.')
        if st.button('Generate evidence-based report',type='primary'):
            key=st.secrets.get('GEMINI_API_KEY','')
            if not key:st.error('Configure GEMINI_API_KEY in Streamlit Secrets.')
            else:
                intel=st.session_state.get('urlsentinel_feed_evidence',{})
                rdap=st.session_state.get('urlsentinel_rdap')
                evidence={'model_assessment':result['prediction'],
                          'experimental_phishing_score_percent':result['phishing_score'],
                          'url_features':result['features'],
                          'openphish':intel,
                          'rdap':rdap if rdap else {'status':'Not checked'}}
                try:
                    with st.spinner('Generating investigation report...'):
                        st.session_state['urlsentinel_report']=generate_investigation_report(evidence,key)
                except Exception as exc:
                    st.error(f'Gemini request failed ({type(exc).__name__}). Check model availability, free-tier limits, and Secrets.')
        report=st.session_state.get('urlsentinel_report')
        if report:
            st.markdown(report)
            st.download_button('Download report',report,file_name='urlsentinel_investigation.md',mime='text/markdown')
        st.caption('AI-generated summaries require investigator review. They do not confirm malicious activity.')

with pages[4]:
    st.subheader('Model Performance')
    evaluation=metrics_data()
    if not evaluation:st.warning('evaluation.json not found in the repository.')
    else:
        a,b,c=st.columns(3)
        a.metric('Original UCI records',f"{evaluation.get('original_records',0):,}")
        b.metric('Cleaned unique records',f"{evaluation.get('cleaned_records',0):,}")
        c.metric('URL-only features',len(evaluation.get('feature_names',[])))
        for key,title in [('random_split','Random train/test split'),('hostname_split','Hostname-separated evaluation')]:
            m=evaluation.get(key)
            if not m:continue
            st.markdown(f'#### {title}')
            cols=st.columns(4)
            for col,(label,field) in zip(cols,[('Accuracy','accuracy'),('Phishing precision','phishing_precision'),('Phishing recall','phishing_recall'),('Phishing F1','phishing_f1')]):
                col.metric(label,f"{m[field]:.2%}")
            cm=m.get('confusion_matrix_labels_0_1')
            if cm:
                st.dataframe(pd.DataFrame(cm,index=['Actual phishing (0)','Actual legitimate (1)'],columns=['Predicted phishing (0)','Predicted legitimate (1)']))
        st.info('These results come from one dataset. They do not establish independent real-world phishing detection performance.')
